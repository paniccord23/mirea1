//
//  Menu.swift
//  MireaApp
//
//  Created by Anna Voronina on 21.05.2020.
//  Copyright © 2020 Anna Voronina. All rights reserved.
//

import Foundation
import UIKit

struct Sale {
    var image: String?
}


struct Menu {
    var name: String?
    var imageName: String?
    var effectImageName: String?
    var dangerImageName: String?
    var description: String?
}

struct List {
    var name: String?
    var imageName: String?
    var effectImageName: String?
    var dangerImageName: String?
    var description: String?
}
struct Brand {
    var name: String?
    var imageName: String?
    var effectImageName: String?
    var dangerImageName: String?
    var description: String?
}
struct Article {
    var name: String?
    var imageName: String?
}

struct Package {
    var name: String?
    var imageName: String?
}

//struct Category {
//    var name = String?
//    var imageName = String?
//    
//    
//}
//
//class SegmentedMenu {
//    var products = [Category]
//    func setup() {
//        let p1 = Category(name: "product1", imageName: UIImage(named: "product")!)
//    }
//}
