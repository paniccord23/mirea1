//
//  BrandSearchViewController.swift
//  MireaApp
//
//  Created by Anna Voronina on 29.05.2020.
//  Copyright © 2020 Anna Voronina. All rights reserved.
//

import UIKit

class BrandSearchViewController: UIViewController{
        let brandNameArr = ["Acqua Di Parma", "Ainhoa", "Alpha - H", "Alterna", "Anasrasia Beverly Hills", "Beautyblender", "Becca", "Belif", "Benefit", "Biotherm", "Bobby Brown", "Bulgary", "By Kilian", "Carolina Herrera", "Chloe", "Clarins", "Clinique", "Creed", "Darphin", "Dior", "Diptyque", "DKNY", "Erborian", "Estee Lauder", "Fentu Beauty", "Givenchy", "Glamglow", "Gucci"]
    var searchedBrand = [String]()
    var searching = false
    
    @IBOutlet weak var brandSearch: UISearchBar!
    
    @IBOutlet weak var tblView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       brandSearch.delegate = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
}
extension BrandSearchViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching {
            return searchedBrand.count
        } else {
            return brandNameArr.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        if searching {
            cell?.textLabel?.text = searchedBrand[indexPath.row]
        } else {
            cell?.textLabel?.text = brandNameArr[indexPath.row]
        }
        return cell!
    }
    
    
}

extension BrandSearchViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        searchedBrand = brandNameArr.filter({$0.lowercased().prefix(searchText.count) == searchText.lowercased()})
        searching = true
        tblView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searching = false
        searchBar.text = ""
        tblView.reloadData()
    }
    
}
