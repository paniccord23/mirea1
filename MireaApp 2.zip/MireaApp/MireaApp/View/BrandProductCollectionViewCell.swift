//
//  BrandProductCollectionViewCell.swift
//  MireaApp
//
//  Created by Anna Voronina on 28.05.2020.
//  Copyright © 2020 Anna Voronina. All rights reserved.
//

import UIKit

class BrandProductCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var effectImage: UIImageView!
    @IBOutlet weak var dangerImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var descriptLabel: UILabel!
    var brand: Brand? {
              didSet{
                  nameLabel.text = brand?.name
                  if let image = brand?.imageName {
                      imageView.image = UIImage(named: image)
                  }
              }
          }
}
