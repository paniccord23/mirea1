//
//  ListCollectionViewCell.swift
//  MireaApp
//
//  Created by Anna Voronina on 25.05.2020.
//  Copyright © 2020 Anna Voronina. All rights reserved.
//

import UIKit

class ListCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var descriptLabel: UILabel!
    @IBOutlet weak var dangerImage: UIImageView!
    @IBOutlet weak var effectImage: UIImageView!
    var list: List? {
           didSet{
               nameLabel.text = list?.name
               if let image = list?.imageName {
                   imageView.image = UIImage(named: image)
               }
           }
       }
}
