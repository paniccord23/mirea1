//
//  ArticleCollectionViewCell.swift
//  MireaApp
//
//  Created by Anna Voronina on 25.05.2020.
//  Copyright © 2020 Anna Voronina. All rights reserved.
//

import UIKit

class ArticleCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!

    
    var article: Article? {
        didSet{
            if let image = article?.imageName {
                imageView.image = UIImage(named: image)
            }
        }
    }
    
}


