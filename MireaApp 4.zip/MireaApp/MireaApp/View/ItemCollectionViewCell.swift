//
//  ItemCollectionViewCell.swift
//  MireaApp
//
//  Created by Anna Voronina on 31.05.2020.
//  Copyright © 2020 Anna Voronina. All rights reserved.
//

import UIKit

class ItemCollectionViewCell: UICollectionViewCell {
    
}
