//
//  PackageCollectionViewCell.swift
//  MireaApp
//
//  Created by Anna Voronina on 25.05.2020.
//  Copyright © 2020 Anna Voronina. All rights reserved.
//

import UIKit

class PackageCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    var package: Package? {
        didSet{
            nameLabel.text = package?.name
            if let image = package?.imageName {
                imageView.image = UIImage(named: image)
            }
        }
    }
}
