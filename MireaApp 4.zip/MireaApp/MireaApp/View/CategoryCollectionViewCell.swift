//
//  CategoryCollectionViewCell.swift
//  MireaApp
//
//  Created by Anna Voronina on 30.05.2020.
//  Copyright © 2020 Anna Voronina. All rights reserved.
//

import UIKit

class CategoryCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    var category: Category? {
              didSet{
                  if let image = category?.imageName {
                    imageView.image = UIImage(named: image)
                  }
              }
          }
}
