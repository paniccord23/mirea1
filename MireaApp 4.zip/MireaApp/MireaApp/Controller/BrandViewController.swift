//
//  BrandViewController.swift
//  MireaApp
//
//  Created by Anna Voronina on 28.05.2020.
//  Copyright © 2020 Anna Voronina. All rights reserved.
//

import UIKit

class BrandViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    var itemBrandArray: [Brand] = {
              var blankBrand = Brand()
              blankBrand.name = "Bobby Brown"
              blankBrand.imageName = "product1"
              blankBrand.dangerImageName = "safe"
              blankBrand.effectImageName = "effective"
              blankBrand.description = "Описание продукта"
           
           var blankBrand1 = Brand()
           blankBrand1.name = "Bobby Brown"
           blankBrand1.imageName = "product2"
           blankBrand1.dangerImageName = "safe"
           blankBrand1.effectImageName = "effective"
           blankBrand1.description = "Описание продукта"
           
           var blankBrand2 = Brand()
           blankBrand2.name = "Bobby Brown"
           blankBrand2.imageName = "product3"
           blankBrand2.dangerImageName = "safe"
           blankBrand2.effectImageName = "effective"
           blankBrand2.description = "Описание продукта"
           
           
           var blankBrand3 = Brand()
           blankBrand3.name = "Bobby Brown"
           blankBrand3.imageName = "product4"
           blankBrand3.dangerImageName = "safe"
           blankBrand3.effectImageName = "effective"
           blankBrand3.description = "Описание продукта"
           
           var blankBrand4 = Brand()
           blankBrand4.name = "Bobby Brown"
           blankBrand4.imageName = "product5"
           blankBrand4.dangerImageName = "safe"
           blankBrand4.effectImageName = "effective"
           blankBrand4.description = "Описание продукта"
           
           var blankBrand5 = Brand()
           blankBrand5.name = "Bobby Brown"
           blankBrand5.imageName = "product4"
           blankBrand5.dangerImageName = "safe"
           blankBrand5.effectImageName = "effective"
           blankBrand5.description = "Описание продукта"
           
           var blankBrand6 = Brand()
           blankBrand6.name = "Bobby Brown"
           blankBrand6.imageName = "product3"
           blankBrand6.dangerImageName = "safe"
           blankBrand6.effectImageName = "effective"
           blankBrand6.description = "Описание продукта"
           
           return[blankBrand,blankBrand1,blankBrand2, blankBrand3,blankBrand4,blankBrand5,blankBrand6]
          }()
       
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

         collectionView.dataSource = self
               collectionView.delegate = self
    }
}

extension BrandViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return itemBrandArray.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let itemCell = collectionView.dequeueReusableCell(withReuseIdentifier: "brandProduct", for: indexPath) as? BrandProductCollectionViewCell {
            itemCell.brand = itemBrandArray[indexPath.row]
            return itemCell
        }
        return UICollectionViewCell()
    }
    
}
