//
//  CategoryListViewController.swift
//  MireaApp
//
//  Created by Anna Voronina on 29.05.2020.
//  Copyright © 2020 Anna Voronina. All rights reserved.
//

import UIKit

class CategoryListViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    
    var categoryArray: [Category] = {
        var blankCategory = Category()
        blankCategory.imageName = "care"
        
        var blankCategory1 = Category()
        blankCategory1.imageName = "decor"
        
        var blankCategory2 = Category()
        blankCategory2.imageName = "eco"
        
        var blankCategory3 = Category()
        blankCategory3.imageName = "vegan"
        
        var blankCategory4 = Category()
        blankCategory4.imageName = "allergic"
        
        return[blankCategory,blankCategory1,blankCategory2, blankCategory3,blankCategory4]
              }()
           
        
        
        override func viewDidLoad() {
            super.viewDidLoad()

             collectionView.dataSource = self
                   collectionView.delegate = self
        }
}

extension CategoryListViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return categoryArray.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let itemCell = collectionView.dequeueReusableCell(withReuseIdentifier: "categoryCell", for: indexPath) as? CategoryCollectionViewCell {
            itemCell.category = categoryArray[indexPath.row]
            return itemCell
        }
        return UICollectionViewCell()
    }
    
}
