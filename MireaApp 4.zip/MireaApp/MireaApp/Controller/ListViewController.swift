//
//  ListViewController.swift
//  MireaApp
//
//  Created by Anna Voronina on 25.05.2020.
//  Copyright © 2020 Anna Voronina. All rights reserved.
//

import UIKit

class ListViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    
    var itemListArray: [List] = {
           var blankList = List()
           blankList.name = "Bobby Brown"
           blankList.imageName = "product1"
           blankList.dangerImageName = "safe"
           blankList.effectImageName = "effective"
           blankList.description = "Описание продукта"
        
        var blankList1 = List()
        blankList1.name = "LimeCrime"
        blankList1.imageName = "product2"
        blankList1.dangerImageName = "safe"
        blankList1.effectImageName = "effective"
        blankList1.description = "Матовая помада"
        
        var blankList2 = List()
        blankList2.name = "Estee Lauder"
        blankList2.imageName = "product3"
        blankList2.dangerImageName = "safe"
        blankList2.effectImageName = "effective"
        blankList2.description = "Компактная пудра-хайлайтер"
        
        
        var blankList3 = List()
        blankList3.name = "Givenchy"
        blankList3.imageName = "product4"
        blankList3.dangerImageName = "safe"
        blankList3.effectImageName = "effective"
        blankList3.description = "Описание продукта"
        
        var blankList4 = List()
        blankList4.name = "La Roche-Posay"
        blankList4.imageName = "product5"
        blankList4.dangerImageName = "safe"
        blankList4.effectImageName = "effective"
        blankList4.description = "Успокаивающая маска для чувствительной кожи"
        
        var blankList5 = List()
        blankList5.name = "Clarins"
        blankList5.imageName = "product2"
        blankList5.dangerImageName = "safe"
        blankList5.effectImageName = "effective"
        blankList5.description = "Молочко для лица"
        
        var blankList6 = List()
        blankList6.name = "Holika-Holika"
        blankList6.imageName = "product4"
        blankList6.dangerImageName = "safe"
        blankList6.effectImageName = "effective"
        blankList6.description = "Маска от черный точек с черным углем"
        
        return[blankList,blankList1,blankList2, blankList3,blankList4,blankList5,blankList6]
       }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        collectionView.dataSource = self
        collectionView.delegate = self
    }
}

extension ListViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return itemListArray.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let itemCell = collectionView.dequeueReusableCell(withReuseIdentifier: "listCell", for: indexPath) as? ListCollectionViewCell {
            itemCell.list = itemListArray[indexPath.row]
            return itemCell
        }
        return UICollectionViewCell()
    }
    
}
