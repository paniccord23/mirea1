//
//  SegmentedTabViewController.swift
//  MireaApp
//
//  Created by Anna Voronina on 26.05.2020.
//  Copyright © 2020 Anna Voronina. All rights reserved.
//

//import UIKit
//
//class SegmentedTabViewController: UIViewController {
//    @IBOutlet weak var collectionView: UICollectionView!
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        self.collectionView.register(UINib(nibName:"ProductCell", bundle: nil), forCellWithReuseIdentifier: "ProductCell")
//        self.collectionView.dataSource = self
//        self.collectionView.delegate = self
//    }
//}
//
//
//extension SegmentedTabViewController:UICollectionViewDataSource, UICollectionViewDelegate {
//    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        return 0
//    }
//    
//    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//       return 1
//    }
//    return UICollectionViewCell
//    
//}
