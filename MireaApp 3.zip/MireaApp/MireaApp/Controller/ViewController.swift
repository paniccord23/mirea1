//
//  ViewController.swift
//  MireaApp
//
//  Created by Anna Voronina on 17.05.2020.
//  Copyright © 2020 Anna Voronina. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var saleCollectionView: UICollectionView!
    
    var itemMenuArray: [Menu] = {
        var blankMenu = Menu()
        blankMenu.name = "Nivea"
        blankMenu.imageName = "product1"
        blankMenu.dangerImageName = "good"
        blankMenu.effectImageName = "effective"
        blankMenu.description = "Описание продукта"
        
        
        var blankMenu1 = Menu()
            blankMenu1.name = "LimeCrime"
            blankMenu1.imageName = "product2"
            blankMenu1.dangerImageName = "good"
            blankMenu1.effectImageName = "effective"
            blankMenu1.description = "Матовая помада"
            
            var blankMenu2 = Menu()
            blankMenu2.name = "Estee Lauder3"
            blankMenu2.imageName = "product3"
            blankMenu2.dangerImageName = "good"
            blankMenu2.effectImageName = "effective"
            blankMenu2.description = "Компактная пудра-хайлайтер"
            
            
            var blankMenu3 = Menu()
            blankMenu3.name = "Givenchy"
            blankMenu3.imageName = "product4"
            blankMenu3.dangerImageName = "good"
            blankMenu3.effectImageName = "effective"
            blankMenu3.description = "Компактная пудра-хайлайтер"
            
            var blankMenu4 = Menu()
            blankMenu4.name = "La Roche-Posay"
            blankMenu4.imageName = "product5"
            blankMenu4.dangerImageName = "good"
            blankMenu4.effectImageName = "effective"
            blankMenu4.description = "Успокаивающая маска для чувствительной кожи"
                
        return[blankMenu, blankMenu1, blankMenu2, blankMenu3, blankMenu4]
    }()
    
    var saleItemArray: [Sale] = {
        var blankSale = Sale()
        blankSale.image = "sale1"
        return[blankSale]
    }()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        collectionView.dataSource = self
//        collectionView.delegate = self
  //      self.collectionView.register(UINib(nibName: "itemCell", bundle: nil), forCellWithReuseIdentifier: "itemCell")
        self.collectionView.dataSource = self
        self.collectionView.delegate = self
        
        
    //    self.saleCollectionView.register(UINib(nibName: "saleCell", bundle: nil), forCellWithReuseIdentifier: "saleCell")
               self.saleCollectionView.dataSource = self
               self.saleCollectionView.delegate = self
    }


}

extension ViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == saleCollectionView{
            return saleItemArray.count
        }
        else {
            return itemMenuArray.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == saleCollectionView  {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "saleCell", for: indexPath) as! SaleCollectionViewCell
            return cell
        }else{
            if let itemCell = collectionView.dequeueReusableCell(withReuseIdentifier: "itemCell", for: indexPath) as? MenuCollectionViewCell {
            itemCell.menu = itemMenuArray[indexPath.row]
            return itemCell
        }
        
        }
        return UICollectionViewCell()
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        if collectionView == saleCollectionView{
            return 3
        }else{
           return 1
        }
    }
}
