//
//  ArticleViewController.swift
//  MireaApp
//
//  Created by Anna Voronina on 25.05.2020.
//  Copyright © 2020 Anna Voronina. All rights reserved.
//

import UIKit

class ArticleViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var packageCollectionView: UICollectionView!
    
    
    var articleArray: [Article] = {
        var blankArticle = Article()
        blankArticle.imageName = "article1"
        return[blankArticle]
    }()
    
    var packageArray: [Package] = {
        var blankPackage = Package()
        blankPackage.imageName = "article1"
        return[blankPackage]
       }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.collectionView.dataSource = self
        self.collectionView.delegate = self
        self.packageCollectionView.dataSource = self
        self.packageCollectionView.delegate = self
        
    }

}
extension ArticleViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == packageCollectionView{
            return packageArray.count
        }
        else {
            return articleArray.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == packageCollectionView {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "packageCell", for: indexPath) as! PackageCollectionViewCell
            return cell
        }else{
            if let itemCell = collectionView.dequeueReusableCell(withReuseIdentifier: "articleCell", for: indexPath) as? ArticleCollectionViewCell {
            itemCell.article = articleArray[indexPath.row]
            return itemCell
        }
        
        }
        return UICollectionViewCell()
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        if collectionView == packageCollectionView{
            return 3
        }else{
           return 5
        }
    }
}
