//
//  ProductCollectionViewCell.swift
//  MireaApp
//
//  Created by Anna Voronina on 26.05.2020.
//  Copyright © 2020 Anna Voronina. All rights reserved.
//

import UIKit

class ProductCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
