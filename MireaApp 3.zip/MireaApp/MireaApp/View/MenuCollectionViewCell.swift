//
//  MenuCollectionViewCell.swift
//  MireaApp
//
//  Created by Anna Voronina on 21.05.2020.
//  Copyright © 2020 Anna Voronina. All rights reserved.
//

import UIKit

class MenuCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    
    @IBOutlet weak var dangerImageView: UIImageView!
    
    @IBOutlet weak var effectImageView: UIImageView!
    
    var menu: Menu? {
        didSet{
            nameLabel.text = menu?.name
            if let image = menu?.imageName {
                imageView.image = UIImage(named: image)
            }
        }
    }
}
