//
//  Menu.swift
//  MireaApp
//
//  Created by Anna Voronina on 21.05.2020.
//  Copyright © 2020 Anna Voronina. All rights reserved.
//

import Foundation

struct Sale {
    var image: String?
}


struct Menu {
    var name: String?
    var imageName: String?
    var effectImageName: String?
    var dangerImageName: String?
    var description: String?
}

struct List {
    var name: String?
    var imageName: String?
    var effectImageName: String?
    var dangerImageName: String?
    var description: String?
}

struct Article {
    var name: String?
    var imageName: String?
}

struct Package {
    var name: String?
    var imageName: String?
}
