//
//  ArticleCollectionViewCell.swift
//  MireaApp
//
//  Created by Anna Voronina on 25.05.2020.
//  Copyright © 2020 Anna Voronina. All rights reserved.
//

import UIKit

class ArticleCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    
    
    var article: Article? {
        didSet{
            nameLabel.text = article?.name
            if let image = article?.imageName {
                imageView.image = UIImage(named: image)
            }
        }
    }
    
}


