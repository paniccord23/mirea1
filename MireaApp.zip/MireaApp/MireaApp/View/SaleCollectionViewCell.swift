//
//  SaleCollectionViewCell.swift
//  MireaApp
//
//  Created by Anna Voronina on 22.05.2020.
//  Copyright © 2020 Anna Voronina. All rights reserved.
//

import UIKit

class SaleCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    
    var sale: Sale? {
        didSet{
            if let image = sale?.image {
                imageView.image = UIImage(named: image)
            }
        }
    }
}
