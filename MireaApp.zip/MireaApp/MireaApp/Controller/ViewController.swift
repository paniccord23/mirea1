//
//  ViewController.swift
//  MireaApp
//
//  Created by Anna Voronina on 17.05.2020.
//  Copyright © 2020 Anna Voronina. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var saleCollectionView: UICollectionView!
    
    var itemMenuArray: [Menu] = {
        var blankMenu = Menu()
        blankMenu.name = "Nivea"
        blankMenu.imageName = "product"
        blankMenu.dangerImageName = "safe"
        blankMenu.effectImageName = "effective"
        blankMenu.description = "Описание продукта"
        return[blankMenu]
    }()
    
    var saleItemArray: [Sale] = {
        var blankSale = Sale()
        blankSale.image = "sales"
        return[blankSale]
    }()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        collectionView.dataSource = self
//        collectionView.delegate = self
  //      self.collectionView.register(UINib(nibName: "itemCell", bundle: nil), forCellWithReuseIdentifier: "itemCell")
        self.collectionView.dataSource = self
        self.collectionView.delegate = self
        
        
    //    self.saleCollectionView.register(UINib(nibName: "saleCell", bundle: nil), forCellWithReuseIdentifier: "saleCell")
               self.saleCollectionView.dataSource = self
               self.saleCollectionView.delegate = self
    }


}

extension ViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == saleCollectionView{
            return saleItemArray.count
        }
        else {
            return itemMenuArray.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == saleCollectionView  {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "saleCell", for: indexPath) as! SaleCollectionViewCell
            return cell
        }else{
            if let itemCell = collectionView.dequeueReusableCell(withReuseIdentifier: "itemCell", for: indexPath) as? MenuCollectionViewCell {
            itemCell.menu = itemMenuArray[indexPath.row]
            return itemCell
        }
        
        }
        return UICollectionViewCell()
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        if collectionView == saleCollectionView{
            return 3
        }else{
           return 5
        }
    }
}
