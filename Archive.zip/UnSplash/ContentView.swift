import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct Home : View {
    
    @State var tabs = ["Nature","Animals","Fish","Flowers"]
    @State var txt = ""
    @State var selectedTab = "Nature"
    
    @State var selectedData : [[String]] = [["s11","s12"],["s21","s22"],["s31","s32"]]
    
    @State var nature = [["s11","s12"],["s21","s22"],["s31","s32"]]
    @State var flowers = [["f11","f12"],["f21","f22"],["f31","f32"]]
    @State var fish = [["m11","m12"],["m21","m22"],["m31","m32"]]
    @State var animals = [["a11","a12"],["a21","a22"],["a31","a32"]]
    
    
    var body : some View{
        
        VStack{
            
            HStack{
                
                Button(action: {
                    
                }) {
                    
                    Image("mirea").renderingMode(.original)
                }
                
                Spacer()
                
                Button(action: {
                    
                }) {
                    
                    Image("search").renderingMode(.original).resizable().frame(width: 25, height: 25)
                }
                
            }.padding()
            .background(Color.black)
            
           
            
            
            ScrollView(.vertical, showsIndicators: false) {
                VStack {
                    Image("banner").padding(20)
                    HStack {
                       Text("Гипоаллергенная").fontWeight(.heavy).font(.title)
                          Spacer()
                        Button(action: {
                            
                        }) {
                            
                            Text("Показать все").fontWeight(.heavy).font(.subheadline)
                        }
                    }.padding(20)
                   
                }
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        Image("kartochka").renderingMode(.original)
                        Image("kartochka").renderingMode(.original)
                        Image("kartochka").renderingMode(.original)
                        Image("kartochka").renderingMode(.original)
                    }.padding(20)
                }
                Spacer()
                VStack {
                    HStack{
                        Text("Бренды").fontWeight(.heavy).font(.title)
                        Spacer()
                        Button(action: {
                            
                        }) {
                            
                            Text("Показать все").fontWeight(.heavy).font(.subheadline)
                        }
                    }.padding(20)
                }
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        Image("brand").renderingMode(.original)
                        Image("brand").renderingMode(.original)
                        Image("brand").renderingMode(.original)
                        Image("brand").renderingMode(.original)
                    }.padding(20)
                }
                   VStack {
                        HStack{
                            Text("Статьи").fontWeight(.heavy).font(.title)
                                Spacer()
                                Button(action: {
                                              
                                }) {
                                              
                                Text("Показать все").fontWeight(.heavy).font(.subheadline)
                                          }
                                      }.padding(20)
                                  }
                                  ScrollView(.horizontal, showsIndicators: false) {
                                      HStack {
                                          Image("artic").renderingMode(.original)
                                          Image("artic").renderingMode(.original)
                                          Image("artic").renderingMode(.original)
                                      }.padding(20)
                                  }
                
                
                VStack(alignment: .leading, spacing: 1) {
                    
                   
                    ZStack(alignment: .topTrailing) {
                        
                        
                        Image("banner").renderingMode(.original)
                        Text("Скидки на веганскую косметику до 40%").font(.title).padding(.top,420)
                      
                        HStack(spacing: 15){
                            
                            Button(action: {
                                
                            }) {
                                
                                Image("add").renderingMode(.original)
                            }
                            
                            Button(action: {
                                
                            }) {
                                
                                Image("favorite").renderingMode(.original)
                            }
                            
                            Button(action: {
                                
                            }) {
                                
                                Image("download").renderingMode(.original)
                            }
                            
                        }.padding()
                    }
                    
                    //Text("Гипоаллергенная").font(.title).padding(.top, 40)
                    
                    HStack(spacing: 15){
                        
                        ForEach(tabs,id: \.self){i in
                            
                            Button(action: {
                                
                                self.selectedTab = i
                                
                                if i == "Акции"{
                                    
                                    self.selectedData = self.nature
                                }
                                else if i == "Fish"{
                                    
                                     self.selectedData = self.fish
                                }
                                else if i == "Animals"{
                                    
                                     self.selectedData = self.animals
                                    
                                }
                                else{
                                    
                                     self.selectedData = self.flowers
                                }
                                
                            }) {
                                
                                VStack{
                                    
                                    Text(i).foregroundColor(.black)
                                    
                                    Capsule()
                                        .fill(self.selectedTab == i ? Color.black : Color.clear)
                                        .frame(height: 6)
                                }
                            }
                        }
                        
                    }.padding(.top)
                    
                    VStack(spacing: 15){
                        
                        ForEach(selectedData,id: \.self){i in
                            
                            HStack{
                                
                                ForEach(i,id: \.self){j in
                                    
                                    Image(j)
                                        .renderingMode(.original)
                                        .resizable()
                                        .frame(width: UIScreen.main.bounds.width / 2 - 20, height: 180)
                                        .contextMenu{
                                            
                                            Button(action: {
                                                
                                                UIImageWriteToSavedPhotosAlbum(UIImage(named: j)!, nil, nil, nil)
                                                
                                            }) {
                                                
                                                HStack{
                                                    
                                                    Text("Save")
                                                    
                                                    Image(systemName: "arrow.down").resizable().frame(width: 15, height: 15)
                                                }
                                            }
                                    }
                                }
                            }
                        }
                        
                    }.padding(.top)
                    
                }.padding()
            }
            
        }.background(Color("bg").edgesIgnoringSafeArea(.bottom))
       }
    }
